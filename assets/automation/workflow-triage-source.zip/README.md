# AI-Assisted Workflow Triage

A synthetic operations-inbox automation project. Node.js 22 or later; no dependencies.

Run offline:

    node --test tests/workflow-triage.test.mjs
    node projects/workflow-triage/run.mjs
    node projects/workflow-triage/run.mjs --scenario clean --threshold 8

For a live AI draft, set OPENAI_API_KEY in your local environment using a secure credential mechanism and choose a model supporting Responses API structured outputs. Never put a key in a file, browser or shell history. Then explicitly run:

    node projects/workflow-triage/run.mjs --ai --model YOUR_MODEL_ID

Only --ai makes an external request. This sends synthetic aggregate evidence to OpenAI and may incur API charges. No request subjects, identifiers or row references are sent. The runner requests store:false; that is not a guarantee about all provider retention policies. No output is automatically submitted, sent or approved.

Controls: required fields, duplicate groups, valid whole-hour request age, supported categories, overdue follow-up. All rows in duplicate groups are excluded. The age snapshot is fixed at 2026-09-30T12:00:00Z; business calendars are not applied. Routing uses supplied categories: access -> Service Desk; billing -> Finance; general -> Operations. Source exceptions block batch release. Plans are proposals only.

The browser page runs checks locally. worked-review.json is an AI-authored portfolio example, not a recorded API response. Tests exercise the API adapter with mocked responses; they do not establish that a live model call has succeeded. Live execution needs the user's own API credential and chosen model. Human review remains required even when structural grounding passes.

The source page uses the parent Quarto portfolio's styles and navigation. The offline CLI and tests run independently from this extracted folder.

Official API documentation: https://developers.openai.com/api/docs/guides/structured-outputs
